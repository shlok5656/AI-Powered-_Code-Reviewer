import React from 'react';
import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar.jsx';
import ReviewPage from './pages/ReviewPage.jsx';
import HistoryPage from './pages/HistoryPage.jsx';
import ResultPage from './pages/ResultPage.jsx';

export default function App() {
  return (
    <div style={{ minHeight: '100vh', display: 'flex', flexDirection: 'column' }}>
      <Navbar />
      <main style={{ flex: 1 }}>
        <Routes>
          <Route path="/" element={<ReviewPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/review/:id" element={<ResultPage />} />
        </Routes>
      </main>
    </div>
  );
}
