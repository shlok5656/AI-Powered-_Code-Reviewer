// utils/api.js
import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

export const submitReview = (data) => api.post('/reviews', data);
export const getReviews = (page = 1) => api.get(`/reviews?page=${page}`);
export const getReview = (id) => api.get(`/reviews/${id}`);
export const deleteReview = (id) => api.delete(`/reviews/${id}`);
