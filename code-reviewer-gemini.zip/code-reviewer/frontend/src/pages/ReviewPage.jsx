import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { submitReview } from '../utils/api.js';

const LANGUAGES = ['javascript', 'typescript', 'python', 'java', 'go', 'rust', 'cpp', 'csharp', 'php', 'ruby', 'swift', 'kotlin', 'sql', 'html', 'css'];

const SAMPLE_CODE = `// Sample JavaScript code with intentional issues
function fetchUserData(userId) {
  const password = "admin123"; // hardcoded credential
  
  var userData = null;
  
  fetch('https://api.example.com/users/' + userId)
    .then(function(response) {
      userData = response.json();
    })
    .then(function() {
      console.log(userData);
    })
}

function calculateTotal(items) {
  var total = 0;
  for(var i = 0; i <= items.length; i++) { // off-by-one bug
    total = total + items[i].price;
  }
  return total;
}`;

export default function ReviewPage() {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [title, setTitle] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const handleSubmit = async () => {
    if (!code.trim()) return setError('Please paste some code to review.');
    setError(''); setLoading(true);
    try {
      const res = await submitReview({ code, language, title });
      navigate(`/review/${res.data.review._id}`);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to connect to server. Is the backend running?');
    } finally {
      setLoading(false);
    }
  };

  const inputStyle = { width: '100%', padding: '0.6rem 1rem', background: 'var(--surface2)', border: '1px solid var(--border)', borderRadius: '8px', color: 'var(--text)', fontSize: '0.9rem', outline: 'none' };
  const btnStyle = (primary) => ({ padding: '0.7rem 1.5rem', borderRadius: '8px', fontWeight: 700, fontSize: '0.9rem', border: 'none', background: primary ? 'var(--accent)' : 'var(--surface2)', color: primary ? '#fff' : 'var(--muted)', transition: 'all 0.2s', opacity: loading ? 0.6 : 1 });

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ marginBottom: '2rem' }}>
        <h1 style={{ fontSize: '2rem', fontWeight: 800, marginBottom: '0.5rem' }}>
          AI Code <span style={{ color: 'var(--accent)' }}>Review</span>
        </h1>
        <p style={{ color: 'var(--muted)' }}>Paste your code and get instant AI-powered feedback on bugs, security, and best practices.</p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '1rem' }}>
        <div>
          <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: 'var(--muted)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Language</label>
          <select value={language} onChange={e => setLanguage(e.target.value)} style={{ ...inputStyle, cursor: 'pointer' }}>
            {LANGUAGES.map(l => <option key={l} value={l}>{l}</option>)}
          </select>
        </div>
        <div>
          <label style={{ display: 'block', fontSize: '0.8rem', fontWeight: 600, color: 'var(--muted)', marginBottom: '0.4rem', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Title (optional)</label>
          <input value={title} onChange={e => setTitle(e.target.value)} placeholder="e.g. Auth service review" style={inputStyle} />
        </div>
      </div>

      <div style={{ marginBottom: '1rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '0.4rem' }}>
          <label style={{ fontSize: '0.8rem', fontWeight: 600, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Code</label>
          <button onClick={() => setCode(SAMPLE_CODE)} style={{ ...btnStyle(false), padding: '0.3rem 0.75rem', fontSize: '0.75rem' }}>Load Sample</button>
        </div>
        <textarea
          value={code}
          onChange={e => setCode(e.target.value)}
          placeholder="// Paste your code here..."
          style={{ ...inputStyle, height: '380px', resize: 'vertical', lineHeight: '1.6', fontSize: '0.85rem' }}
        />
      </div>

      {error && (
        <div style={{ padding: '0.75rem 1rem', background: '#f5656522', border: '1px solid #f56565', borderRadius: '8px', color: '#fc8181', marginBottom: '1rem', fontSize: '0.9rem' }}>
          ⚠ {error}
        </div>
      )}

      <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
        <button onClick={handleSubmit} disabled={loading} style={btnStyle(true)}>
          {loading ? '⏳ Analyzing...' : '🔍 Review Code'}
        </button>
        {loading && <span style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>AI is reviewing your code...</span>}
      </div>
    </div>
  );
}
