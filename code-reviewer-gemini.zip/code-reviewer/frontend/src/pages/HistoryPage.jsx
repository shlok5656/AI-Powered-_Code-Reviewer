import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { getReviews, deleteReview } from '../utils/api.js';

export default function HistoryPage() {
  const [data, setData] = useState({ reviews: [], total: 0, pages: 1 });
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const load = async (p = 1) => {
    setLoading(true);
    try {
      const res = await getReviews(p);
      setData(res.data);
      setPage(p);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(1); }, []);

  const handleDelete = async (id, e) => {
    e.preventDefault();
    if (!confirm('Delete this review?')) return;
    await deleteReview(id);
    load(page);
  };

  const scoreColor = (s) => s >= 80 ? '#68d391' : s >= 60 ? '#f6ad55' : '#f56565';

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
        <div>
          <h1 style={{ fontSize: '1.8rem', fontWeight: 800 }}>Review <span style={{ color: 'var(--accent)' }}>History</span></h1>
          <p style={{ color: 'var(--muted)', marginTop: '0.25rem' }}>{data.total} total reviews</p>
        </div>
        <Link to="/" style={{ padding: '0.6rem 1.2rem', background: 'var(--accent)', color: '#fff', borderRadius: '8px', fontWeight: 700, fontSize: '0.9rem' }}>+ New Review</Link>
      </div>

      {loading ? (
        <div style={{ textAlign: 'center', padding: '3rem', color: 'var(--muted)' }}>Loading...</div>
      ) : data.reviews.length === 0 ? (
        <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--muted)' }}>
          <p style={{ fontSize: '3rem', marginBottom: '1rem' }}>📭</p>
          <p>No reviews yet. <Link to="/">Submit your first review!</Link></p>
        </div>
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          {data.reviews.map(r => (
            <Link key={r._id} to={`/review/${r._id}`} style={{ textDecoration: 'none', color: 'inherit' }}>
              <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '12px', padding: '1.25rem 1.5rem', display: 'grid', gridTemplateColumns: '1fr auto auto', gap: '1.5rem', alignItems: 'center', transition: 'border-color 0.2s', cursor: 'pointer' }}>
                <div>
                  <h3 style={{ fontWeight: 700, marginBottom: '0.25rem' }}>{r.title}</h3>
                  <div style={{ display: 'flex', gap: '0.75rem', color: 'var(--muted)', fontSize: '0.8rem' }}>
                    <span style={{ background: 'var(--surface2)', padding: '0.1rem 0.5rem', borderRadius: '4px' }}>{r.language}</span>
                    <span>{r.issues?.length ?? 0} issues</span>
                    <span>{new Date(r.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
                <div style={{ textAlign: 'center' }}>
                  <div style={{ fontSize: '1.5rem', fontWeight: 800, color: scoreColor(r.score) }}>{r.score}</div>
                  <div style={{ fontSize: '0.7rem', color: 'var(--muted)' }}>/ 100</div>
                </div>
                <button onClick={(e) => handleDelete(r._id, e)} style={{ background: 'none', border: '1px solid var(--border)', color: 'var(--danger)', padding: '0.4rem 0.75rem', borderRadius: '6px', fontSize: '0.8rem', cursor: 'pointer' }}>🗑</button>
              </div>
            </Link>
          ))}
        </div>
      )}

      {data.pages > 1 && (
        <div style={{ display: 'flex', justifyContent: 'center', gap: '0.5rem', marginTop: '2rem' }}>
          {Array.from({ length: data.pages }, (_, i) => (
            <button key={i} onClick={() => load(i + 1)} style={{ padding: '0.4rem 0.75rem', borderRadius: '6px', border: '1px solid var(--border)', background: page === i + 1 ? 'var(--accent)' : 'var(--surface)', color: page === i + 1 ? '#fff' : 'var(--muted)', cursor: 'pointer', fontWeight: 600 }}>{i + 1}</button>
          ))}
        </div>
      )}
    </div>
  );
}
