import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { getReview } from '../utils/api.js';
import ScoreRing from '../components/ScoreRing.jsx';
import IssueCard from '../components/IssueCard.jsx';

const SEVERITY_ORDER = { critical: 0, high: 1, medium: 2, low: 3, info: 4 };

export default function ResultPage() {
  const { id } = useParams();
  const [review, setReview] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [showCode, setShowCode] = useState(false);

  useEffect(() => {
    getReview(id).then(r => setReview(r.data)).catch(() => setError('Review not found.')).finally(() => setLoading(false));
  }, [id]);

  if (loading) return <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--muted)' }}>Loading review...</div>;
  if (error) return <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--danger)' }}>{error}</div>;

  const sorted = [...(review.issues || [])].sort((a, b) => (SEVERITY_ORDER[a.severity] ?? 5) - (SEVERITY_ORDER[b.severity] ?? 5));
  const counts = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  sorted.forEach(i => { if (counts[i.severity] !== undefined) counts[i.severity]++; });

  const card = { background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: '12px', padding: '1.5rem', marginBottom: '1.5rem' };
  const badge = (n, color) => n > 0 ? <span style={{ background: `${color}22`, color, fontSize: '0.75rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '4px', marginRight: '0.4rem' }}>{n} {Object.entries(counts).find(([,v]) => v === n && color)?.[0] || ''}</span> : null;

  return (
    <div style={{ maxWidth: '900px', margin: '0 auto', padding: '2rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', marginBottom: '2rem' }}>
        <Link to="/" style={{ color: 'var(--muted)', fontSize: '0.9rem', textDecoration: 'none' }}>← New Review</Link>
        <span style={{ color: 'var(--border)' }}>|</span>
        <Link to="/history" style={{ color: 'var(--muted)', fontSize: '0.9rem', textDecoration: 'none' }}>History</Link>
      </div>

      <h1 style={{ fontSize: '1.6rem', fontWeight: 800, marginBottom: '0.25rem' }}>{review.title}</h1>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', marginBottom: '2rem' }}>
        <span style={{ background: 'var(--surface2)', color: 'var(--muted)', fontSize: '0.8rem', padding: '0.2rem 0.75rem', borderRadius: '4px' }}>{review.language}</span>
        <span style={{ color: 'var(--muted)', fontSize: '0.8rem' }}>{new Date(review.createdAt).toLocaleString()}</span>
      </div>

      {/* Score + Summary */}
      <div style={{ ...card, display: 'grid', gridTemplateColumns: '150px 1fr', gap: '2rem', alignItems: 'center' }}>
        <ScoreRing score={review.score} />
        <div>
          <h2 style={{ fontWeight: 700, marginBottom: '0.75rem' }}>Summary</h2>
          <p style={{ color: 'var(--muted)', lineHeight: 1.7 }}>{review.summary}</p>
          <div style={{ marginTop: '1rem', display: 'flex', flexWrap: 'wrap', gap: '0.4rem' }}>
            {counts.critical > 0 && <span style={{ background: '#f5656522', color: '#f56565', fontSize: '0.75rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '4px' }}>{counts.critical} critical</span>}
            {counts.high > 0 && <span style={{ background: '#fc818122', color: '#fc8181', fontSize: '0.75rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '4px' }}>{counts.high} high</span>}
            {counts.medium > 0 && <span style={{ background: '#f6ad5522', color: '#f6ad55', fontSize: '0.75rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '4px' }}>{counts.medium} medium</span>}
            {counts.low > 0 && <span style={{ background: '#63b3ed22', color: '#63b3ed', fontSize: '0.75rem', fontWeight: 700, padding: '0.2rem 0.6rem', borderRadius: '4px' }}>{counts.low} low</span>}
          </div>
        </div>
      </div>

      {/* Issues */}
      <div style={card}>
        <h2 style={{ fontWeight: 700, marginBottom: '1rem' }}>Issues ({sorted.length})</h2>
        {sorted.length === 0
          ? <p style={{ color: 'var(--success)' }}>✓ No issues found — great code!</p>
          : sorted.map((issue, i) => <IssueCard key={i} issue={issue} />)
        }
      </div>

      {/* Positives */}
      {review.positives?.length > 0 && (
        <div style={card}>
          <h2 style={{ fontWeight: 700, marginBottom: '1rem' }}>✓ What's Good</h2>
          <ul style={{ listStyle: 'none', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
            {review.positives.map((p, i) => (
              <li key={i} style={{ display: 'flex', gap: '0.75rem', color: 'var(--muted)', fontSize: '0.9rem' }}>
                <span style={{ color: 'var(--success)' }}>✓</span> {p}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Code toggle */}
      <div style={card}>
        <button onClick={() => setShowCode(!showCode)} style={{ background: 'none', border: 'none', color: 'var(--accent)', fontWeight: 700, fontSize: '0.9rem', cursor: 'pointer' }}>
          {showCode ? '▲ Hide Code' : '▼ Show Submitted Code'}
        </button>
        {showCode && (
          <pre style={{ marginTop: '1rem', background: 'var(--bg)', padding: '1rem', borderRadius: '8px', overflow: 'auto', fontSize: '0.82rem', lineHeight: 1.6, color: 'var(--text)' }}>
            {review.code}
          </pre>
        )}
      </div>
    </div>
  );
}
