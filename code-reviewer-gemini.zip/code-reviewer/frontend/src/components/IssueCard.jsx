import React, { useState } from 'react';

const SEVERITY_COLORS = { critical: '#f56565', high: '#fc8181', medium: '#f6ad55', low: '#63b3ed', info: '#68d391' };
const TYPE_ICONS = { bug: '🐛', security: '🔒', performance: '⚡', style: '🎨', suggestion: '💡' };

export default function IssueCard({ issue }) {
  const [open, setOpen] = useState(false);
  const color = SEVERITY_COLORS[issue.severity] || '#718096';

  return (
    <div onClick={() => setOpen(!open)} style={{ background: 'var(--surface2)', border: `1px solid ${color}33`, borderLeft: `3px solid ${color}`, borderRadius: '8px', padding: '0.75rem 1rem', cursor: 'pointer', transition: 'all 0.2s', marginBottom: '0.5rem' }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem', flex: 1 }}>
          <span>{TYPE_ICONS[issue.type] || '•'}</span>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ background: `${color}22`, color, fontSize: '0.7rem', fontWeight: 700, padding: '0.15rem 0.5rem', borderRadius: '4px', textTransform: 'uppercase' }}>{issue.severity}</span>
              <span style={{ color: 'var(--muted)', fontSize: '0.75rem', textTransform: 'capitalize' }}>{issue.type}</span>
              {issue.line && <span style={{ color: 'var(--muted)', fontSize: '0.75rem' }}>line {issue.line}</span>}
            </div>
            <p style={{ marginTop: '0.25rem', fontSize: '0.9rem' }}>{issue.message}</p>
          </div>
        </div>
        <span style={{ color: 'var(--muted)', fontSize: '0.8rem' }}>{open ? '▲' : '▼'}</span>
      </div>
      {open && issue.suggestion && (
        <div style={{ marginTop: '0.75rem', padding: '0.75rem', background: 'var(--bg)', borderRadius: '6px', fontSize: '0.85rem', color: 'var(--accent2)', fontFamily: 'var(--mono)' }}>
          💡 {issue.suggestion}
        </div>
      )}
    </div>
  );
}
