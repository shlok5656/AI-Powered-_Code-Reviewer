import React from 'react';

export default function ScoreRing({ score }) {
  const r = 54, c = 2 * Math.PI * r;
  const pct = Math.max(0, Math.min(100, score));
  const dash = (pct / 100) * c;
  const color = score >= 80 ? '#68d391' : score >= 60 ? '#f6ad55' : '#f56565';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '0.5rem' }}>
      <svg width="130" height="130" viewBox="0 0 130 130">
        <circle cx="65" cy="65" r={r} fill="none" stroke="var(--border)" strokeWidth="10" />
        <circle cx="65" cy="65" r={r} fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={`${dash} ${c}`} strokeLinecap="round"
          transform="rotate(-90 65 65)" style={{ transition: 'stroke-dasharray 1s ease' }} />
        <text x="65" y="60" textAnchor="middle" fill={color} fontSize="28" fontWeight="800" fontFamily="Syne">{pct}</text>
        <text x="65" y="80" textAnchor="middle" fill="var(--muted)" fontSize="11" fontFamily="Syne">/ 100</text>
      </svg>
      <span style={{ color, fontWeight: 700, fontSize: '0.9rem' }}>
        {score >= 80 ? '✓ Excellent' : score >= 60 ? '⚠ Needs Work' : '✗ Major Issues'}
      </span>
    </div>
  );
}
