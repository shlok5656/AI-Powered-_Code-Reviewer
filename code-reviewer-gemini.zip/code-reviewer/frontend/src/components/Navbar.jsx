import React from 'react';
import { Link, useLocation } from 'react-router-dom';

export default function Navbar() {
  const { pathname } = useLocation();
  const nav = { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '1rem 2rem', background: 'var(--surface)', borderBottom: '1px solid var(--border)', position: 'sticky', top: 0, zIndex: 100 };
  const logo = { fontWeight: 800, fontSize: '1.25rem', color: 'var(--accent)', letterSpacing: '-0.5px' };
  const linkStyle = (path) => ({ padding: '0.4rem 1rem', borderRadius: '6px', fontWeight: 600, fontSize: '0.9rem', color: pathname === path ? 'var(--accent)' : 'var(--muted)', background: pathname === path ? 'rgba(124,106,247,0.12)' : 'transparent', transition: 'all 0.2s' });

  return (
    <nav style={nav}>
      <Link to="/" style={{ ...logo, textDecoration: 'none' }}>
        ⬡ CodeReview<span style={{ color: 'var(--accent2)' }}>AI</span>
      </Link>
      <div style={{ display: 'flex', gap: '0.5rem' }}>
        <Link to="/" style={linkStyle('/')}>Review</Link>
        <Link to="/history" style={linkStyle('/history')}>History</Link>
      </div>
    </nav>
  );
}
