# ⬡ CodeReview AI — Full Stack Setup Guide

A full-stack AI-powered code reviewer using **Anthropic Claude**, **Express**, **MongoDB**, and **React**.

---

## 🗂 Project Structure

```
code-reviewer/
├── backend/
│   ├── config/
│   │   └── database.js        ← MongoDB connection
│   ├── models/
│   │   └── Review.js          ← Mongoose schema
│   ├── routes/
│   │   └── reviews.js         ← REST API endpoints
│   ├── services/
│   │   └── aiService.js       ← Anthropic Claude integration
│   ├── server.js              ← Express app entry point
│   ├── .env.example           ← Environment variable template
│   └── package.json
└── frontend/
    ├── src/
    │   ├── components/        ← Reusable UI components
    │   ├── pages/             ← Route-level pages
    │   └── utils/api.js       ← Axios API client
    ├── index.html
    └── package.json
```

---

## ─────────────────────────────────────────
## STEP 1 — Get FREE Gemini API Key
## ─────────────────────────────────────────

1. Go to **https://aistudio.google.com/app/apikey**
2. Sign in with your Google account
3. Click **"Create API Key"**
4. Copy the key — looks like: `AIzaSyXXXXXXXXXXXXXXXXX`

> ✅ **100% Free** — 15 requests/min, 1 million tokens/day, no credit card needed.

---

## ─────────────────────────────────────────
## STEP 2 — Setup MongoDB
## ─────────────────────────────────────────

### Option A: MongoDB Atlas (Cloud — Recommended, Free)

1. Go to **https://www.mongodb.com/atlas**
2. Create free account → Create **Free M0 cluster**
3. **Security → Database Access** → Add user (username + password)
4. **Security → Network Access** → Add IP: `0.0.0.0/0` (allow all) or your IP
5. **Database → Connect → Drivers** → Copy connection string

   It looks like:
   ```
   mongodb+srv://myuser:mypassword@cluster0.abcde.mongodb.net/?retryWrites=true&w=majority
   ```

6. Add database name to the URI:
   ```
   mongodb+srv://myuser:mypassword@cluster0.abcde.mongodb.net/code_reviewer?retryWrites=true&w=majority
   ```

### Option B: Local MongoDB

1. Download from **https://www.mongodb.com/try/download/community**
2. Install and start:
   ```bash
   # macOS (Homebrew)
   brew tap mongodb/brew
   brew install mongodb-community
   brew services start mongodb-community

   # Windows — run as Administrator:
   net start MongoDB

   # Linux (Ubuntu)
   sudo systemctl start mongod
   ```
3. Your URI will be:
   ```
   mongodb://localhost:27017/code_reviewer
   ```

---

## ─────────────────────────────────────────
## STEP 3 — Backend Setup
## ─────────────────────────────────────────

```bash
cd backend

# Install dependencies
npm install

# Create your .env file
cp .env.example .env
```

Edit `.env` with your actual values:
```env
GEMINI_API_KEY=AIzaSy-your-actual-key-here
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/code_reviewer
PORT=5000
FRONTEND_URL=http://localhost:5173
```

Start the backend:
```bash
# Development (auto-restarts on changes)
npm run dev

# Production
npm start
```

✅ You should see:
```
✅ MongoDB Connected: cluster0.xxxxx.mongodb.net
🚀 Server running on http://localhost:5000
📋 API: http://localhost:5000/api/reviews
```

---

## ─────────────────────────────────────────
## STEP 4 — Frontend Setup
## ─────────────────────────────────────────

```bash
cd frontend

# Install dependencies
npm install

# Start development server
npm run dev
```

✅ Open **http://localhost:5173** in your browser.

> The Vite dev server proxies `/api` → `http://localhost:5000` automatically (configured in `vite.config.js`).

---

## ─────────────────────────────────────────
## STEP 5 — Test the Full Flow
## ─────────────────────────────────────────

1. Open http://localhost:5173
2. Select a language (e.g., JavaScript)
3. Click **"Load Sample"** to use demo code, or paste your own
4. Click **"Review Code"**
5. Wait ~5 seconds for AI analysis
6. View results: score, issues, and suggestions!

### Manual API Test (curl):
```bash
curl -X POST http://localhost:5000/api/reviews \
  -H "Content-Type: application/json" \
  -d '{
    "title": "Test Review",
    "language": "javascript",
    "code": "var x = 1\nconsole.log(x)"
  }'
```

---

## 🔌 API Endpoints

| Method | URL | Description |
|--------|-----|-------------|
| POST | `/api/reviews` | Submit code for AI review |
| GET | `/api/reviews` | List all reviews (paginated) |
| GET | `/api/reviews/:id` | Get a specific review |
| DELETE | `/api/reviews/:id` | Delete a review |
| GET | `/health` | Health check |

---

## 🗃 MongoDB Schema

```js
Review {
  title: String,
  code: String,           // submitted code
  language: String,       // e.g. "javascript"
  score: Number,          // 0-100 AI score
  summary: String,        // AI summary text
  issues: [{
    type: String,         // bug|security|performance|style|suggestion
    severity: String,     // critical|high|medium|low|info
    line: Number,         // optional line number
    message: String,      // issue description
    suggestion: String    // how to fix
  }],
  positives: [String],    // what the code does well
  rawResponse: String,    // raw AI response (debug)
  createdAt: Date,
  updatedAt: Date
}
```

---

## 🔧 Troubleshooting

### "Invalid Gemini API key"
→ Check your `GEMINI_API_KEY` in `.env`. Get it free at https://aistudio.google.com/app/apikey

### "MongoDB connection failed"
→ For Atlas: verify your IP is whitelisted in Network Access  
→ For Atlas: verify your username/password are correct  
→ For Local: run `mongod` first to start MongoDB server

### Frontend can't reach backend
→ Make sure backend is running on port 5000  
→ Check `vite.config.js` proxy settings

### CORS errors
→ Make sure `FRONTEND_URL=http://localhost:5173` in backend `.env`

---

## 🚀 Production Deployment

### Backend (Railway / Render / Fly.io)
1. Push to GitHub
2. Connect to Railway/Render
3. Set environment variables: `ANTHROPIC_API_KEY`, `MONGODB_URI`, `FRONTEND_URL`
4. Deploy

### Frontend (Vercel / Netlify)
1. Update `frontend/src/utils/api.js` baseURL to your backend URL
2. Deploy frontend folder to Vercel/Netlify

---

## 🛡 Security Notes

- Never expose `ANTHROPIC_API_KEY` in frontend code
- Always validate input on the backend
- Add rate limiting in production (`npm install express-rate-limit`)
- Use MongoDB Atlas IP whitelisting in production
