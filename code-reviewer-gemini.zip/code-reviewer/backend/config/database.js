// config/database.js
import mongoose from 'mongoose';

const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI, {
      // These options ensure stable connection
      serverSelectionTimeoutMS: 5000,
      socketTimeoutMS: 45000,
    });

    console.log(`✅ MongoDB Connected: ${conn.connection.host}`);

    mongoose.connection.on('error', (err) => {
      console.error('❌ MongoDB connection error:', err);
    });

    mongoose.connection.on('disconnected', () => {
      console.warn('⚠️  MongoDB disconnected. Attempting reconnect...');
    });

  } catch (error) {
    console.error('❌ MongoDB connection failed:', error.message);
    console.error('\n📋 TROUBLESHOOTING:');
    console.error('   1. Check your MONGODB_URI in .env');
    console.error('   2. For Atlas: Whitelist your IP in Network Access');
    console.error('   3. For Local: Run "mongod" to start MongoDB');
    process.exit(1);
  }
};

export default connectDB;
