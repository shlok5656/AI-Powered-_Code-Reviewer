// models/Review.js
import mongoose from 'mongoose';

const issueSchema = new mongoose.Schema({
  type: { type: String, enum: ['bug', 'security', 'performance', 'style', 'suggestion'], required: true },
  severity: { type: String, enum: ['critical', 'high', 'medium', 'low', 'info'], required: true },
  line: { type: Number },
  message: { type: String, required: true },
  suggestion: { type: String },
});

const reviewSchema = new mongoose.Schema({
  title: { type: String, default: 'Untitled Review' },
  code: { type: String, required: true },
  language: { type: String, required: true },
  summary: { type: String },
  score: { type: Number, min: 0, max: 100 },
  issues: [issueSchema],
  positives: [String],
  rawResponse: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

reviewSchema.pre('save', function (next) {
  this.updatedAt = Date.now();
  next();
});

export default mongoose.model('Review', reviewSchema);
