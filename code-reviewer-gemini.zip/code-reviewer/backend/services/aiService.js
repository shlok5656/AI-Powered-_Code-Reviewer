// services/aiService.js
import { GoogleGenerativeAI } from '@google/generative-ai';

// Reads GEMINI_API_KEY from .env automatically
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);

const PROMPT_TEMPLATE = (language, code) => `
You are an expert code reviewer. Analyze the following ${language} code and respond ONLY with valid JSON — no markdown, no explanation, just raw JSON.

JSON structure:
{
  "score": <number 0-100>,
  "summary": "<2-3 sentence overview>",
  "issues": [
    {
      "type": "<bug|security|performance|style|suggestion>",
      "severity": "<critical|high|medium|low|info>",
      "line": <number or null>,
      "message": "<clear description>",
      "suggestion": "<how to fix>"
    }
  ],
  "positives": ["<what the code does well>"]
}

Code to review:
\`\`\`${language}
${code}
\`\`\`
`;

export const analyzeCode = async (code, language) => {
  try {
    const model = genAI.getGenerativeModel({ model: 'gemini-1.5-flash' });

    const result = await model.generateContent(PROMPT_TEMPLATE(language, code));
    const rawText = result.response.text();

    // Strip any markdown fences Gemini may add
    const cleaned = rawText.replace(/```json\n?|\n?```/g, '').trim();
    const parsed = JSON.parse(cleaned);

    return {
      score: parsed.score ?? 50,
      summary: parsed.summary ?? 'Review completed.',
      issues: parsed.issues ?? [],
      positives: parsed.positives ?? [],
      rawResponse: rawText,
    };
  } catch (error) {
    if (error.message?.includes('API_KEY_INVALID') || error.message?.includes('API key not valid')) {
      throw new Error('Invalid Gemini API key. Check GEMINI_API_KEY in .env');
    }
    if (error.status === 429 || error.message?.includes('quota')) {
      throw new Error('Gemini rate limit exceeded. Please wait a moment and try again.');
    }
    throw error;
  }
};
