// routes/reviews.js
import express from 'express';
import { analyzeCode } from '../services/aiService.js';
import Review from '../models/Review.js';

const router = express.Router();

// POST /api/reviews — Submit code for review
router.post('/', async (req, res) => {
  try {
    const { code, language, title } = req.body;
    if (!code || !language) return res.status(400).json({ error: 'code and language are required' });
    if (code.length > 50000) return res.status(400).json({ error: 'Code too long (max 50,000 chars)' });

    // Call AI
    const aiResult = await analyzeCode(code, language);

    // Save to MongoDB
    const review = new Review({ title: title || `${language} Review`, code, language, ...aiResult });
    await review.save();

    res.status(201).json({ success: true, review });
  } catch (error) {
    console.error('Review error:', error.message);
    res.status(500).json({ error: error.message });
  }
});

// GET /api/reviews — List all reviews (paginated)
router.get('/', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const limit = parseInt(req.query.limit) || 10;
    const skip = (page - 1) * limit;

    const [reviews, total] = await Promise.all([
      Review.find({}, '-code -rawResponse').sort({ createdAt: -1 }).skip(skip).limit(limit),
      Review.countDocuments(),
    ]);

    res.json({ reviews, total, page, pages: Math.ceil(total / limit) });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// GET /api/reviews/:id — Get single review
router.get('/:id', async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ error: 'Review not found' });
    res.json(review);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// DELETE /api/reviews/:id
router.delete('/:id', async (req, res) => {
  try {
    await Review.findByIdAndDelete(req.params.id);
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

export default router;
